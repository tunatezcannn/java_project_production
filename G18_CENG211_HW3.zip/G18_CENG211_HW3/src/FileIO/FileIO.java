package FileIO;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import Manufacturers.*;
import RawMaterials.Material;
import RawMaterials.MaterialQualityPair;
import RawMaterials.Vendor;

/**  
 * @author  Şermin Beyza Yurdakan 280201028
 * @author  Esra Ekmekci 280201050
 * @author  Tuna Tezcan 280201060
 */
public class FileIO {
	public List<Furniture> furnitures = new ArrayList<Furniture>();
	
	public List<Material> materials = new ArrayList<Material>();
	
	public List<MaterialQualityPair> vendorArr = new ArrayList<MaterialQualityPair>();
	
	public Vendor tempVendor;
	
	public FileIO() throws IOException{
		readMaterials();
		readFurniture();
		getVendorItems();
		tempVendor = new Vendor(vendorArr);
	}
	/**
	 * reads furnitures from files
	 * @throws IOException
	 */
	public void readFurniture() throws IOException{
		BufferedReader reader = new BufferedReader(new FileReader("FurnitureParts.csv"));
		
		List<String> furnitureValues = new ArrayList<String>();
		//Here we hold them in array to get names by index.		
		String[] furnitureIDs = {"TB1401","TB1402","TB1501","TB1502","TB1503","WD2201",
					  "WD2202","WD2203","SH5001","SH5002","SH5003","SH5101"};	
		String[] furnitureNames = {"Obsidian","Pearl","Elegant","Walnut","Garden","Lavinia","Loki",
						"Atlas","Corner","Harmony","Luna","Hittite"};
		//be able to use indexOf
		for(String elem: furnitureIDs){
			furnitureValues.add(elem);
		}
		
		String line;
		
		while((line = reader.readLine()) != null) {
			String[] splittedString = line.split(",");
			String furnitureID = splittedString[0];
			Queue<Material> materialArray = new ArrayDeque<Material>();
	 		
			switch(furnitureID.charAt(0)) {
			 	case 'T':{
			 		String furnitureName = furnitureNames[furnitureValues.indexOf(furnitureID)];
			 		int i = 1;
			 		while(i+1 < splittedString.length) {
			 			int count = Integer.parseInt(splittedString[i+1]);
			 			//in here we take the materials which we need to use in order to 
			 			//produce furnitures and add them into array
			 			for(Material material : materials) {
			 				if (splittedString[i].equals(material.getMaterialCode())) {
			 					for(int a=0; a<count; a++) {
			 						materialArray.add(material);
			 					}
			 				}
			 			}
			 			i += 2;
			 		}
			 		
			 		Furniture newTable = new Table(furnitureID,furnitureName,materialArray);
			 		furnitures.add(newTable);
			 		break;
			 	} 
			 	case 'W':{
			 		String furnitureName = furnitureNames[furnitureValues.indexOf(furnitureID)];
			 		int i = 1;
			 		while(i+1 < splittedString.length) {
			 			int count = Integer.parseInt(splittedString[i+1]);
			 			
			 			for(Material material : materials) {
			 				if (splittedString[i].equals(material.getMaterialCode())) {
			 					for(int a=0; a<count; a++) {
			 						materialArray.add(material);
			 					}
			 				}
			 			}
			 			i += 2;
			 		}
			 		
			 		Furniture newWardrobe = new Wardrobe(furnitureID,furnitureName,materialArray);
			 		furnitures.add(newWardrobe);
			 		break;
			 	} 
			 	case 'S':{
			 		String furnitureName = furnitureNames[furnitureValues.indexOf(furnitureID)];
			 		int i = 1;
			 		while(i+1 < splittedString.length) {
			 			int count = Integer.parseInt(splittedString[i+1]);
			 			
			 			for(Material material : materials) {
			 				if (splittedString[i].equals(material.getMaterialCode())) {
			 					for(int a=0; a<count; a++) {
			 						materialArray.add(material);
			 					}
			 				}
			 			}
			 			i += 2;
			 		}
			 		
			 		Furniture newShelf = new Shelf(furnitureID,furnitureName,materialArray);
			 		furnitures.add(newShelf);
			 		break;
			 	} 
				default:
					throw new IllegalArgumentException("Unexpected value: " + furnitureID.charAt(0));
			 	}
			
			}
		reader.close();			
	}
	/**
	 * This gets all vendor materials from the file
	 * and adds to the vendors material array
	 * @throws NumberFormatException
	 * @throws IOException
	 */
	public void getVendorItems() throws NumberFormatException, IOException {
		BufferedReader reader = new BufferedReader(new FileReader("VendorPossessions.csv"));
		
		String line;
		
		while((line = reader.readLine()) != null) {
			String materialID = line.split(",")[0];
			int quality = Integer.parseInt(line.split(",")[1]);
			for(Material material : materials) {
 				if (materialID.equals(material.getMaterialCode())) {
 					MaterialQualityPair temp = new MaterialQualityPair(material, quality);
 					vendorArr.add(temp);		
 				}
 			}		
		}
		reader.close();
	}
	/**
	 * Gets production order and the materials manufacturer will buy
	 * from file and adds them into 3 different arrays
	 * which is for each day
	 * @param materialFileName
	 * @param furnitureFileName
	 * @return Manufacturer
	 * @throws NumberFormatException
	 * @throws IOException
	 */
	public Manufacturer getManufacturer(String materialFileName, String furnitureFileName) throws NumberFormatException, IOException {
		BufferedReader reader = new BufferedReader(new FileReader(materialFileName));
		String line;
		Queue<Material> materialArrayDay1 = new ArrayDeque<Material>();
		Queue<Material> materialArrayDay2 = new ArrayDeque<Material>();
		Queue<Material> materialArrayDay3 = new ArrayDeque<Material>();
		
		while((line = reader.readLine()) != null) {
			String[] splittedString = line.split(",");
			int day = Integer.parseInt(splittedString[0]);
			//for every line we control the first for determining the day
	 		int i = 1;
	 		while(i+1 < splittedString.length) {
	 			//for every step we are looking for double elements
	 			//one is for material one is for the number of material
	 			//and we add materials but not with numbers
	 			//if we have 10 material we add 10 material to the array
	 			int count = Integer.parseInt(splittedString[i+1]);
	 			for(Material material : materials) {
	 				if (splittedString[i].equals(material.getMaterialCode())&& day == 1) {
	 					for(int a = 0;a<count;a++) {
	 						materialArrayDay1.add(material);
	 					}		
	 				}
	 				else if(splittedString[i].equals(material.getMaterialCode())&& day == 2) {
	 					for(int a = 0;a<count;a++) {
	 						materialArrayDay2.add(material);
	 					}	
	 				}
	 				else if(splittedString[i].equals(material.getMaterialCode())&& day == 3){
	 					for(int a = 0;a<count;a++) {
	 						materialArrayDay3.add(material);
	 					}	
	 				}
	 			}
	 			i+=2;
	 		}
 		}
		
		reader.close();
		
		BufferedReader reader2 = new BufferedReader(new FileReader(furnitureFileName));
		String line2;
		Queue<Furniture> furnitureArrayDay1 = new ArrayDeque<Furniture>();
		Queue<Furniture> furnitureArrayDay2 = new ArrayDeque<Furniture>();
		Queue<Furniture> furnitureArrayDay3 = new ArrayDeque<Furniture>();
		
		while((line2 = reader2.readLine()) != null) {
			String[] splittedString = line2.split(",");
			int day = Integer.parseInt(splittedString[0]);
			//for every line we control the first for determining the day
	 		int i = 1;
	 		while(i+1 < splittedString.length) {
	 			//for every step we are looking for double elements
	 			//one is for furniture one is for the number of furniture
	 			//and we add furniture but not with numbers
	 			//if we have 10 furniture we add 10 furniture to the array
	 			int count = Integer.parseInt(splittedString[i+1]);
	 			for(Furniture furniture : furnitures) {
	 				if (splittedString[i].equals(furniture.getFurnitureCode())&& day == 1) {
	 					for(int a = 0;a<count;a++) {
	 						furnitureArrayDay1.add(furniture);
	 					}		
	 				}
	 				else if(splittedString[i].equals(furniture.getFurnitureCode())&& day == 2) {
	 					for(int a = 0;a<count;a++) {
	 						furnitureArrayDay2.add(furniture);
	 					}	
	 				}
	 				else if(splittedString[i].equals(furniture.getFurnitureCode())&& day == 3){
	 					for(int a = 0;a<count;a++) {
	 						furnitureArrayDay3.add(furniture);
	 					}	
	 				}
	 			}
	 			i+=2;
	 		}
 		}	
		//we are returning manufacturer according to the file name
		Manufacturer returnMan;
		if (materialFileName.equals("Manufacturer1Materials.csv")) {
			returnMan = new Manufacturer1(materialArrayDay1, materialArrayDay2, 
					 materialArrayDay3, furnitureArrayDay1, 
					 furnitureArrayDay2, furnitureArrayDay3);
		}
		else {
			returnMan = new Manufacturer2(materialArrayDay1, materialArrayDay2, 
					 materialArrayDay3, furnitureArrayDay1, 
					 furnitureArrayDay2, furnitureArrayDay3);
		}
		

		reader2.close();
		return returnMan;
	}
	/**
	 * this gets material properties and holds them in a list for 
	 * use them when we need
	 * @throws IOException
	 */
	private void readMaterials() throws IOException{
		BufferedReader reader = new BufferedReader(new FileReader("RawMaterialProperties.csv"));
		String line;
		
		while((line = reader.readLine()) != null) {
			String materialID = line.split(",")[0];
			int length = Integer.parseInt(line.split(",")[1]);
			int width = Integer.parseInt(line.split(",")[2]);
			int height = Integer.parseInt(line.split(",")[3]);
			int cost = Integer.parseInt(line.split(",")[4]);
			
			float volume = length * width * height;
			
			Material newMaterial = new Material(materialID, volume, cost);
			
			materials.add(newMaterial);
		}
		
		reader.close();
	}
}
