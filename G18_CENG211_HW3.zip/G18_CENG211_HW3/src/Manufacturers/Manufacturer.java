package Manufacturers;

import java.util.*;
import RawMaterials.*;
/**  
 * abstract class which have abstract start production method 
 * @author  Şermin Beyza Yurdakan 280201028
 * @author  Esra Ekmekci 280201050
 * @author  Tuna Tezcan 280201060
 */

public abstract class Manufacturer implements IManufacturer{
	//manufacturer envantory
	private Queue<MaterialQualityPair> materialsManufacturerHave = new ArrayDeque<MaterialQualityPair>();
	
	//hold materials which we buy from vendor for every day
	private Queue<Material> day1MaterialList = new ArrayDeque<Material>();
	private Queue<Material> day2MaterialList = new ArrayDeque<Material>();
	private Queue<Material> day3MaterialList = new ArrayDeque<Material>();	
	
	//hold furnitures which we produce every day
	private Queue<Furniture> furnitureArrayDay1 = new ArrayDeque<Furniture>();
	private Queue<Furniture> furnitureArrayDay2 = new ArrayDeque<Furniture>();
	private Queue<Furniture> furnitureArrayDay3 = new ArrayDeque<Furniture>();
	
	public Manufacturer(Queue<Material> day1MaterialList, Queue<Material> day2MaterialList,
			Queue<Material> day3MaterialList, Queue<Furniture> furnitureArrayDay1, Queue<Furniture> furnitureArrayDay2,
			Queue<Furniture> furnitureArrayDay3) {
		this.day1MaterialList = day1MaterialList;
		this.day2MaterialList = day2MaterialList;
		this.day3MaterialList = day3MaterialList;
		this.furnitureArrayDay1 = furnitureArrayDay1;
		this.furnitureArrayDay2 = furnitureArrayDay2;
		this.furnitureArrayDay3 = furnitureArrayDay3;
	}
	
	/**
	 * getting manufacturer envantory in arraylist form
	*/
	public List<Material> getMaterialFromInventory(){
		List<Material> temp = new ArrayList<Material>();
		for(MaterialQualityPair pair: materialsManufacturerHave) {
			temp.add(pair.getMaterial());
		}
		return temp;
	}
	/**
	 * production
	 */
	public abstract void startProduction(int day);
	
	/**
	 * calculates total cost and income with taking furnitures array
	 */
	public void calculateTotal(ArrayDeque<Furniture> furnitures) {
		double totalCost = 0, totalIncome = 0;
		for (Furniture furniture: furnitures) {
			totalCost += furniture.getCost();
			totalIncome += furniture.getIncome();
		}
		System.out.println("\nTotal Expense: " + totalCost);
		System.out.println("Total Income: " + totalIncome + "\n");
	}
	
	/**
	 * calculates quality with using used materials array
	 */
	public double calculateQuality(ArrayDeque<MaterialQualityPair> usedMaterials) {
		double totalQualityVolume = 0;
		double totalVolume = 0;
		for(MaterialQualityPair pair: usedMaterials) {
			totalQualityVolume += pair.getQuality()*pair.getMaterial().getVolume();
			totalVolume += pair.getMaterial().getVolume();
		}
		return totalQualityVolume/totalVolume;
	}
	
	/**
	 * buys materials from vendor
	*/
	public void buyMaterialFromVendor(int day, Vendor vendor) {
		List<MaterialQualityPair> vendorArr = vendor.getVendorArr();
		Queue<Material> temp = new ArrayDeque<Material>();
		switch (day) {
		case 1: {
			temp = getDay1MaterialList();
			break;
		}
		case 2: {
			temp = getDay2MaterialList();
			break;
		}
		case 3: {
			temp = getDay3MaterialList();
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + day);
		}
		
		for(Material elem: temp) {
			for(MaterialQualityPair pair: vendorArr) {
				if(elem.getMaterialCode().equals(pair.getMaterial().getMaterialCode())) {
					getMaterialsManufacturerHave().add(pair);
					vendorArr.remove(pair); 
					break;
				}
			}
		}
	}
	
	/**
	 * this controls for if manufacturer haves enough materials to produce furniture
	*/
	public boolean controlForEnoughMaterial(Furniture furniture) {
		if(getMaterialFromInventory().containsAll(furniture.getMaterialArray())) {
			return true;
		}
		return false;
	}
	
	/**
	 * prints
	 * @param producedFurnitures
	 * @param furnitureName
	 */
	public void printProduced(ArrayDeque<Furniture> producedFurnitures,String furnitureName) {
		int bq=0,nq=0,gq=0,vgq=0,pq=0;
		double earning=0;
		for(Furniture furniture : producedFurnitures) {
			if(furniture.getFurnitureName().equals(furnitureName)) {
				switch (furniture.getQualityRange()) {
				case "Bad Qlt": {
					bq++;
					break;
				}
				case "Normal Qlt": {
					nq++;
					break;
				}
				case "Good Qlt": {
					gq++;
					break;
				}
				case "Very Good Qlt": {
					vgq++;
					break;
				}
				case "Perfect Qlt": {
					pq++;
					break;
				}
				default:
					throw new IllegalArgumentException("Unexpected value: " + furniture.getQualityRange());
				}
				
				earning += furniture.getIncome() - furniture.getCost();
			}
			
		}
		System.out.println(furnitureName + ":   " + "Bad Qlt: " + bq + ", Normal Qlt: " + nq
										 + ", Good Qlt: " + gq + ", Very Good Qlt: " + vgq
										 + ", Perfect Qlt: " + pq + ", Earning: " + earning + " TL \n");			
		
	}
	/**
	 * print unproduced furnitures with counts
	 */
	public  void printUnproduced(ArrayDeque<Furniture> unproducedFurnitureArray, String furnitureName) {
			int count = 0;
			for(Furniture f: unproducedFurnitureArray) {
				if(f.getFurnitureName().equals(furnitureName)) {
					count++;
				}
			}
			if(furnitureName.equals(unproducedFurnitureArray.getLast().getFurnitureName())) {
				System.out.print(count + " " + furnitureName + ".");
			}
			else {
				System.out.print(count + " " + furnitureName + ", ");
			}
	}
	
	public Queue<MaterialQualityPair> getMaterialsManufacturerHave() {
		return materialsManufacturerHave;
	}

	public void setMaterialsManufacturerHave(Queue<MaterialQualityPair> materialsManufacturerHave) {
		this.materialsManufacturerHave = materialsManufacturerHave;
	}

	public Queue<Material> getDay1MaterialList() {
		return day1MaterialList;
	}

	public Queue<Material> getDay2MaterialList() {
		return day2MaterialList;
	}

	public Queue<Material> getDay3MaterialList() {
		return day3MaterialList;
	}

	public Queue<Furniture> getFurnitureArrayDay1() {
		return furnitureArrayDay1;
	}

	public Queue<Furniture> getFurnitureArrayDay2() {
		return furnitureArrayDay2;
	}

	public Queue<Furniture> getFurnitureArrayDay3() {
		return furnitureArrayDay3;
	}
}
