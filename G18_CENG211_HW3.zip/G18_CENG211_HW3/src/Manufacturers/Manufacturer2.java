package Manufacturers;

import java.util.*;

import RawMaterials.Material;
import RawMaterials.MaterialQualityPair;
/** 
* @author  Şermin Beyza Yurdakan 280201028
* @author  Esra Ekmekci 280201050
* @author  Tuna Tezcan 280201060
*/
public class Manufacturer2 extends Manufacturer{

	public Manufacturer2(Queue<Material> day1MaterialList, Queue<Material> day2MaterialList,
			Queue<Material> day3MaterialList, Queue<Furniture> furnitureArrayDay1, Queue<Furniture> furnitureArrayDay2,
			Queue<Furniture> furnitureArrayDay3) {
		super(day1MaterialList, day2MaterialList, day3MaterialList, furnitureArrayDay1, furnitureArrayDay2, furnitureArrayDay3);
	}

	@Override
	public void startProduction(int day) {
		ArrayDeque<Furniture> furnitureArray = new ArrayDeque<>();;
		ArrayDeque<Furniture> unproducedFurnitureArray = new ArrayDeque<>();
		ArrayDeque<Furniture> producedFurnitures = new ArrayDeque<>();
		ArrayDeque<MaterialQualityPair> usedMaterials = new ArrayDeque<>();
		
		switch (day) {
		case 1: {
			furnitureArray = (ArrayDeque<Furniture>) getFurnitureArrayDay1();
			break;
		}
		case 2: {
			furnitureArray = (ArrayDeque<Furniture>) getFurnitureArrayDay2();
			break;
		}
		case 3: {
			furnitureArray = (ArrayDeque<Furniture>) getFurnitureArrayDay3();
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + day);
		}
		
		ArrayDeque<MaterialQualityPair> manufacturerEnvantory = (ArrayDeque<MaterialQualityPair>)getMaterialsManufacturerHave();
		int count = furnitureArray.size();
		for(int i = 0; i < count;i++) {
			//we get first because of fifo
			Furniture temp = furnitureArray.removeFirst();
			if(controlForEnoughMaterial(temp)) {
				List<Material> matTemp =  temp.getMaterialArrayList();
				for(int a = temp.getMaterialArray().size()-1;a>0;a--) {
					for(MaterialQualityPair pair: manufacturerEnvantory) {
						//then we compare every element in furniture material array
						//with envantory if we see equality
						//we add it in used materials to calculate quality and
						//remove from the envantory
						if(matTemp.get(a).getMaterialCode().equals(pair.getMaterial().getMaterialCode())) {
							usedMaterials.add(pair);
							manufacturerEnvantory.remove(pair);
							break;
						}
					}
				}
				//setting properties
				temp.setQuality(calculateQuality(usedMaterials));
				temp.setQualityRange();
				temp.setCost();
				temp.arrangeIncome();
				producedFurnitures.add(temp);
			}
			//if we can not produce we add it into another list
			else {
				unproducedFurnitureArray.add(temp);
			}
		}
		//printing produced
		String name = "";
		for(Furniture f : producedFurnitures) {
			if (!name.equals(f.getFurnitureName())) {
				printProduced(producedFurnitures, f.getFurnitureName());
				name = f.getFurnitureName();
			}
		}
		//printing total price
		calculateTotal(producedFurnitures);

		System.out.println("\nUnproduced Furnitures: ");
		name = "";
		//printing unproduced
		for(Furniture f : unproducedFurnitureArray) {
			if (!name.equals(f.getFurnitureName())) {
				printUnproduced(unproducedFurnitureArray, f.getFurnitureName());				
				name = f.getFurnitureName();
			}	
		}
		//in here if we couldnt produce furniture in one day
		//we add it to the other days produce list
		if(day==1) {
			int count1 = unproducedFurnitureArray.size();
			for(int j = 0;j<count1;j++) {
				((ArrayDeque<Furniture>)getFurnitureArrayDay2()).addFirst(unproducedFurnitureArray.removeLast());
			}
		}
		else if(day==2) {
			int count1 = unproducedFurnitureArray.size();
			for(int j = 0;j<count1;j++) {
				((ArrayDeque<Furniture>)getFurnitureArrayDay3()).addFirst(unproducedFurnitureArray.removeLast());
			}
	}
}
	




}
