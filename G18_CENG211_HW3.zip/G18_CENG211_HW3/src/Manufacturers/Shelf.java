package Manufacturers;

import java.util.*;

import RawMaterials.Material;
/** 
* @author  Şermin Beyza Yurdakan 280201028
* @author  Esra Ekmekci 280201050
* @author  Tuna Tezcan 280201060
*/
public class Shelf extends Furniture{

	public Shelf(String furnitureCode, String furnitureName, Queue<Material> materialArray) {
		super(furnitureCode, furnitureName, materialArray);
	}
	public Shelf() {
		super();
	}
	
	public void arrangeIncome() {
		double cost = 0;
		for (Material material: getMaterialArray()) {
			cost += material.getCost();
		}
		super.setIncome(cost*2.8);
	}

}
