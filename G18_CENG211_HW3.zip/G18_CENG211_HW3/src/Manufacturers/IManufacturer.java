package Manufacturers;

import java.util.ArrayDeque;
import java.util.List;

import RawMaterials.Material;
import RawMaterials.MaterialQualityPair;
import RawMaterials.Vendor;
/** 
* @author  Şermin Beyza Yurdakan 280201028
* @author  Esra Ekmekci 280201050
* @author  Tuna Tezcan 280201060
*/
public interface IManufacturer {
	public List<Material> getMaterialFromInventory();
	public abstract void startProduction(int day);
	public void calculateTotal(ArrayDeque<Furniture> furnitures);
	public double calculateQuality(ArrayDeque<MaterialQualityPair> usedMaterials);
	public void buyMaterialFromVendor(int day, Vendor vendor);
	public boolean controlForEnoughMaterial(Furniture furniture);
	public  void printUnproduced(ArrayDeque<Furniture> unproducedFurnitureArray, String furnitureName);
}
