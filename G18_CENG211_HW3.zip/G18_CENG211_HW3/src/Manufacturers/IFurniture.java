package Manufacturers;

import java.util.List;

import RawMaterials.Material;
/** 
* @author  Şermin Beyza Yurdakan 280201028
* @author  Esra Ekmekci 280201050
* @author  Tuna Tezcan 280201060
*/
public interface IFurniture {
	public abstract void arrangeIncome();
	public List<Material> getMaterialArrayList();
}
