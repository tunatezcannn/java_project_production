package Manufacturers;
import java.util.*;
import RawMaterials.Material;
/**
 * this is abstract class which have abstract
 * arrange income method implemented in sublclasses
 * for every furniture type	
 * 
 * @author  Şermin Beyza Yurdakan 280201028
 * @author  Esra Ekmekci 280201050
 * @author  Tuna Tezcan 280201060
 */
public abstract class Furniture implements IFurniture {
	private String furnitureCode,furnitureName, qualityRange;
	private double quality,income,cost;
	//we used array deque because we can remove and add elements to the end and start easily
	private Queue<Material> materialArray = new ArrayDeque<Material>();
	
	public Furniture(String furnitureCode, String furnitureName, Queue<Material> materialArray) {
		this.furnitureCode = furnitureCode;
		this.furnitureName = furnitureName;
		this.materialArray = materialArray;
	}
	public Furniture() {
		
	}

	public String getFurnitureCode() {
		return furnitureCode;
	}

	public void setFurnitureCode(String furnitureCode) {
		this.furnitureCode = furnitureCode;
	}

	public String getFurnitureName() {
		return furnitureName;
	}

	public void setFurnitureName(String furnitureName) {
		this.furnitureName = furnitureName;
	}


	public Queue<Material> getMaterialArray() {
		return materialArray;
	}

	public void setMaterialArray(Queue<Material>materialArray) {
		this.materialArray = materialArray;
	}

	public double getQuality() {
		return quality;
	}

	public void setQuality(double quality) {
		this.quality = quality;
	}

	public String getQualityRange() {
		return qualityRange;
	}

	public void setQualityRange() {
		if(quality < 92) {
			qualityRange = "Bad Qlt";	
		}
		else if(quality >= 92 && quality < 94) {
			qualityRange = "Normal Qlt";
		}
		else if(quality >= 94 && quality < 96) {
			qualityRange = "Good Qlt";
		}
		else if(quality >= 96 && quality < 98) {
			qualityRange = "Very Good Qlt";
		}
		else if(quality >= 98) {
			qualityRange = "Perfect Qlt";
		}
		else {
			System.out.println("unexpected value: " + quality);
		}
//		System.out.println(quality);
	}

	public double getIncome() {
		return income;
	}

	public void setIncome(double income) {
		this.income = income;
	}	
	
	public abstract void arrangeIncome();
	
	public double getCost() {
		return cost;
	}
	
	public void setCost() {
		this.cost=0;
		for(Material m: materialArray) {
			this.cost += m.getCost();
		}
	}
	
	//to convert array deque to arraylist
	public List<Material> getMaterialArrayList(){
		List<Material> temp = new ArrayList<Material>();
		for(Material a: materialArray) {
			temp.add(a);
		}
		return temp;
	}
	
	
}
