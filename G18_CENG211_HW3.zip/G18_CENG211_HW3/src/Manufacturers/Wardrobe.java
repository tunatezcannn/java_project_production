package Manufacturers;


import java.util.Queue;
import RawMaterials.Material;
/** 
* @author  Şermin Beyza Yurdakan 280201028
* @author  Esra Ekmekci 280201050
* @author  Tuna Tezcan 280201060
*/
public class Wardrobe extends Furniture{

	public Wardrobe(String furnitureCode, String furnitureName, Queue<Material> materialArray) {
		super(furnitureCode, furnitureName, materialArray);
	}

	public Wardrobe() {
		super();
	}

	public void arrangeIncome() {
		double cost = 0;
		for (Material material: getMaterialArray()) {
			cost += material.getCost();
		}
		super.setIncome(cost*3.2);
	}
}
