package App;

import java.io.IOException;
/**  
 * @author  Şermin Beyza Yurdakan 280201028
 * @author  Esra Ekmekci 280201050
 * @author  Tuna Tezcan 280201060
 */
public class FurnitureFactorySimulationApp {
	//Main app
	public static void main(String[] args) throws IOException {
		FurnitureFactorySimulationQuery q = new FurnitureFactorySimulationQuery();
		q.start();
	}
}
