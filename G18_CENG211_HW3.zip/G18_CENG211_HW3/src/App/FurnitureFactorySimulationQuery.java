package App;

import java.io.IOException;
import FileIO.FileIO;
import Manufacturers.*;
import RawMaterials.*;
/**   
 * @author  Şermin Beyza Yurdakan 280201028
 * @author  Esra Ekmekci 280201050
 * @author  Tuna Tezcan 280201060
 */
public class FurnitureFactorySimulationQuery {
	
	Vendor vendor;
	/**
	 * it starts production simulation
	 * @throws IOException
	 */
	public void start() throws IOException {
		FileIO f = new FileIO();
		//Getting manufacturers from fileIO
		Manufacturer manufacturer1 = f.getManufacturer("Manufacturer1Materials.csv",
																		"Manufacturer1Furnitures.csv");
		Manufacturer manufacturer2 = f.getManufacturer("Manufacturer2Materials.csv",
				"Manufacturer2Furnitures.csv");	
		
		vendor = f.tempVendor;
		//Process
		System.out.println("DAY 1:");
		System.out.println("\nManufacturer 1:\n");
		buyMaterialFromVendor(manufacturer1, 1);
		startProduction(1, manufacturer1,1);
		System.out.println("\n\nManufacturer 2:\n");
		buyMaterialFromVendor(manufacturer2, 1);
		startProduction(2, manufacturer2,1);
		
		System.out.println("\n\nDAY 2:");
		System.out.println("\nManufacturer 1:\n");
		buyMaterialFromVendor(manufacturer1, 2);
		startProduction(1, manufacturer1,2);
		System.out.println("\n\nManufacturer 2:\n");
		buyMaterialFromVendor(manufacturer2, 2);
		startProduction(2, manufacturer2,2);
		
		System.out.println("\n\nDAY 3:");
		System.out.println("\nManufacturer 1:\n");
		buyMaterialFromVendor(manufacturer1, 3);
		startProduction(1, manufacturer1,3);
		System.out.println("\n\nManufacturer 2:\n");
		buyMaterialFromVendor(manufacturer2, 3);
		startProduction(2, manufacturer2,3);
	}
	
	/**
	 * buys material from vendor with given day and manufacturer
	 * @param manufacturer
	 * @param day
	 */
	private void buyMaterialFromVendor(Manufacturer manufacturer, int day) {
		manufacturer.buyMaterialFromVendor(day, vendor);
	}
	
	private void startProduction(int manNum, Manufacturer manufacturer,int day) {
		if (manNum == 1) {
			((Manufacturer1) manufacturer).startProduction(day);			
		}
		else {
			((Manufacturer2) manufacturer).startProduction(day);
		}
	}

}
