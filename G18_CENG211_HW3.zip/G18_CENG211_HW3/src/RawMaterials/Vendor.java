package RawMaterials;

import java.util.*;
/** 
 * @author  Şermin Beyza Yurdakan 280201028
 * @author  Esra Ekmekci 280201050
 * @author  Tuna Tezcan 280201060
 */
public class Vendor {
	private List<MaterialQualityPair> vendorArr = new ArrayList<MaterialQualityPair>();

	public Vendor(List<MaterialQualityPair> vendorArr) {
		this.vendorArr = vendorArr;
	}

	public List<MaterialQualityPair> getVendorArr() {
		return vendorArr;
	}

	public void setVendorArr(List<MaterialQualityPair> vendorArr) {
		this.vendorArr = vendorArr;
	}
	
}
