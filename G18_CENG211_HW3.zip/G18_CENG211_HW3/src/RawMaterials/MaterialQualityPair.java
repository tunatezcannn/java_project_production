package RawMaterials;


/** 
 * 
 * when we get item from vendor we need to hold
 * with quality of material to do this
 * we implement this
 * 
 * @author  Şermin Beyza Yurdakan 280201028
 * @author  Esra Ekmekci 280201050
 * @author  Tuna Tezcan 280201060
 */
public class MaterialQualityPair {
	Material material;
	int quality;
	
	public MaterialQualityPair(Material material, int quality) {
		this.material = material;
		this.quality = quality;
	}
	public Material getMaterial() {
		return material;
	}
	public void setMaterial(Material material) {
		this.material = material;
	}
	public int getQuality() {
		return quality;
	}
	public void setQuality(int quality) {
		this.quality = quality;
	}
	
}
