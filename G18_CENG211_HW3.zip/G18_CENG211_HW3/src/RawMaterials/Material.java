package RawMaterials;

/** 
 * holds materials with properties
 * 
 * @author  Şermin Beyza Yurdakan 280201028
 * @author  Esra Ekmekci 280201050
 * @author  Tuna Tezcan 280201060
 */
public class Material{
	
	private String materialCode;
	private float volume;
	private float cost;
	
	public Material(String materialCode, float volume, float cost) {
		this.materialCode = materialCode;
		this.volume = volume;
		this.cost = cost;
	}

	public String getMaterialCode() {
		return materialCode;
	}

	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	public float getVolume() {
		return volume;
	}

	public void setVolume(float volume) {
		this.volume = volume;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}
}
